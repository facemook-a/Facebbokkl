/*
 *  OpenVPN -- An application to securely tunnel IP networks
 *             over a single TCP/UDP port, with support for SSL/TLS-based
 *             session authentication and key exchange,
 *             packet encryption, packet authentication, and
 *             packet compression.
 *
 *  Copyright (C) 2002-2026 OpenVPN Inc <sales@openvpn.net>
 *  Copyright (C) 2010-2026 Sentyron B.V. <openvpn@sentyron.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2
 *  as published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file
 * Control Channel Verification Module OpenSSL implementation
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "syshead.h"

#if defined(ENABLE_CRYPTO_OPENSSL)

#include "ssl_verify_openssl.h"

#include "error.h"
#include "ssl_openssl.h"
#include "ssl_verify.h"
#include "ssl_verify_backend.h"
#include "openssl_compat.h"

#include <openssl/bn.h>
#include <openssl/err.h>
#include <openssl/x509v3.h>

int
verify_callback(int preverify_ok, X509_STORE_CTX *ctx)
{
    int ret = 0;
    struct tls_session *session;
    SSL *ssl;
    struct gc_arena gc = gc_new();

    /* get the tls_session pointer */
    ssl = X509_STORE_CTX_get_ex_data(ctx, SSL_get_ex_data_X509_STORE_CTX_idx());
    ASSERT(ssl);
    session = (struct tls_session *)SSL_get_ex_data(ssl, mydata_index);
    ASSERT(session);

    X509 *current_cert = X509_STORE_CTX_get_current_cert(ctx);
    struct buffer cert_hash = x509_get_sha256_fingerprint(current_cert, &gc);
    cert_hash_remember(session, X509_STORE_CTX_get_error_depth(ctx), &cert_hash);

    /* did peer present cert which was signed by our root cert? */
    if (!preverify_ok && !session->opt->verify_hash_no_ca)
    {
        /* get the X509 name */
        char *subject = x509_get_subject(current_cert, &gc);
        char *serial = backend_x509_get_serial(current_cert, &gc);

        if (!subject)
        {
            subject = "(Failed to retrieve certificate subject)";
        }

        /* Log and ignore missing CRL errors */
        if (X509_STORE_CTX_get_error(ctx) == X509_V_ERR_UNABLE_TO_GET_CRL)
        {
            msg(D_TLS_DEBUG_LOW, "VERIFY WARNING: depth=%d, %s: %s",
                X509_STORE_CTX_get_error_depth(ctx),
                X509_verify_cert_error_string(X509_STORE_CTX_get_error(ctx)), subject);
            ret = 1;
            goto cleanup;
        }

        /* Remote site specified a certificate, but it's not correct */
        msg(D_TLS_ERRORS, "VERIFY ERROR: depth=%d, error=%s: %s, serial=%s",
            X509_STORE_CTX_get_error_depth(ctx),
            X509_verify_cert_error_string(X509_STORE_CTX_get_error(ctx)), subject,
            serial ? serial : "<not available>");

        ERR_clear_error();

        session->verified = false;
        goto cleanup;
    }

    if (SUCCESS != verify_cert(session, current_cert, X509_STORE_CTX_get_error_depth(ctx)))
    {
        goto cleanup;
    }

    ret = 1;

cleanup:
    gc_free(&gc);

    return ret;
}

bool
x509_username_field_ext_supported(const char *fieldname)
{
    int nid = OBJ_txt2nid(fieldname);
    return nid == NID_subject_alt_name || nid == NID_issuer_alt_name;
}

static bool
extract_x509_extension(X509 *cert, char *fieldname, char *out, size_t size)
{
    bool retval = false;

    if (!x509_username_field_ext_supported(fieldname))
    {
        msg(D_TLS_ERRORS, "ERROR: --x509-username-field 'ext:%s' not supported", fieldname);
        return false;
    }

    int nid = OBJ_txt2nid(fieldname);
    GENERAL_NAMES *extensions = X509_get_ext_d2i(cert, nid, NULL, NULL);
    if (extensions)
    {
        /* get amount of alternatives,
         * RFC2459 claims there MUST be at least
         * one, but we don't depend on it...
         */

        openssl_stack_size_t numalts = sk_GENERAL_NAME_num(extensions);

        /* loop through all alternatives */
        for (openssl_stack_size_t i = 0; i < numalts; i++)
        {
            /* get a handle to alternative name number i */
            const GENERAL_NAME *name = sk_GENERAL_NAME_value(extensions, i);
            char *buf = NULL;

            switch (name->type)
            {
                case GEN_EMAIL:
                    if (ASN1_STRING_to_UTF8((unsigned char **)&buf, name->d.rfc822Name) < 0)
                    {
                        continue;
                    }
                    if ((ssize_t)strlen(buf) != ASN1_STRING_length(name->d.rfc822Name))
                    {
                        msg(D_TLS_ERRORS, "ASN1 ERROR: string contained terminating zero");
                    }
                    else if (strlcpy(out, buf, size) >= size)
                    {
                        msg(D_TLS_ERRORS, "ASN1 ERROR: string too long");
                    }
                    else
                    {
                        retval = true;
                    }
                    OPENSSL_free(buf);
                    break;

                default:
                    msg(D_TLS_DEBUG, "%s: ignoring general name field type %d", __func__,
                        name->type);
                    break;
            }
        }
        GENERAL_NAMES_free(extensions);
    }
    return retval;
}

/*
 * Extract a field from an X509 subject name.
 *
 * Example:
 *
 * /C=US/ST=CO/L=Denver/O=ORG/CN=First-CN/CN=Test-CA/Email=jim@yonan.net
 *
 * The common name is 'Test-CA'
 *
 * Return true on success, false on error (insufficient buffer size in 'out'
 * to contain result is grounds for error).
 */
static result_t
extract_x509_field_ssl(const X509_NAME *x509, const char *field_name, char *out, size_t size)
{
    int lastpos = -1;
    int tmp = -1;
    unsigned char *buf = NULL;
    result_t ret = FAILURE;

    ASN1_OBJECT *field_name_obj = OBJ_txt2obj(field_name, 0);
    if (field_name_obj == NULL)
    {
        msg(D_TLS_ERRORS, "Invalid X509 attribute name '%s'", field_name);
        goto exit;
    }

    ASSERT(size > 0);
    *out = '\0';
    do
    {
        lastpos = tmp;
#if OPENSSL_VERSION_NUMBER >= 0x30000000L
        tmp = X509_NAME_get_index_by_OBJ(x509, field_name_obj, lastpos);
#else
        /* OpenSSL 1.1.x has the argument as non-const */
        tmp = X509_NAME_get_index_by_OBJ((X509_NAME *)x509, field_name_obj, lastpos);
#endif
    } while (tmp > -1);

    ASN1_OBJECT_free(field_name_obj);

    /* Nothing found */
    if (lastpos == -1)
    {
        goto exit;
    }

    const X509_NAME_ENTRY *x509ne = X509_NAME_get_entry(x509, lastpos);
    if (!x509ne)
    {
        goto exit;
    }

    const ASN1_STRING *asn1 = X509_NAME_ENTRY_get_data(x509ne);
    if (!asn1)
    {
        goto exit;
    }
    int length = ASN1_STRING_to_UTF8(&buf, asn1);
    if (length < 0 || (size_t)length != strlen((char *)buf))
    {
        goto exit;
    }

    ret = (strlcpy(out, (char *)buf, size) < size) ? SUCCESS : FAILURE;

exit:
    OPENSSL_free(buf);
    return ret;
}

result_t
backend_x509_get_username(char *common_name, size_t cn_len, char *x509_username_field, X509 *peer_cert)
{
    if (strncmp("ext:", x509_username_field, 4) == 0)
    {
        if (!extract_x509_extension(peer_cert, x509_username_field + 4, common_name, cn_len))
        {
            return FAILURE;
        }
    }
    else if (strcmp(LN_serialNumber, x509_username_field) == 0)
    {
        const ASN1_INTEGER *asn1_i = X509_get_serialNumber(peer_cert);

        BIGNUM *bn_serial = ASN1_INTEGER_to_BN(asn1_i, NULL);
        char *serial = BN_bn2hex(bn_serial);
        BN_free(bn_serial);

        if (!serial || cn_len <= strlen(serial) + 2)
        {
            OPENSSL_free(serial);
            return FAILURE;
        }
        snprintf(common_name, cn_len, "0x%s", serial);
        OPENSSL_free(serial);
    }
    else
    {
        const X509_NAME *x509_subject_name = X509_get_subject_name(peer_cert);
        if (x509_subject_name == NULL)
        {
            msg(D_TLS_ERRORS, "X509 subject name is NULL");
            return FAILURE;
        }

        if (FAILURE
            == extract_x509_field_ssl(x509_subject_name, x509_username_field,
                                      common_name, cn_len))
        {
            return FAILURE;
        }
    }

    return SUCCESS;
}

char *
backend_x509_get_serial(openvpn_x509_cert_t *cert, struct gc_arena *gc)
{
    ASN1_INTEGER *asn1_i;
    BIGNUM *bignum;
    char *openssl_serial, *serial;

    asn1_i = X509_get_serialNumber(cert);
    bignum = ASN1_INTEGER_to_BN(asn1_i, NULL);
    openssl_serial = BN_bn2dec(bignum);

    serial = string_alloc(openssl_serial, gc);

    BN_free(bignum);
    OPENSSL_free(openssl_serial);

    return serial;
}

char *
backend_x509_get_serial_hex(openvpn_x509_cert_t *cert, struct gc_arena *gc)
{
    const ASN1_INTEGER *asn1_i = X509_get_serialNumber(cert);
    BIGNUM *bn_serial = ASN1_INTEGER_to_BN(asn1_i, NULL);
    int len_serial = BN_num_bytes(bn_serial);
    unsigned char *buf = malloc(len_serial);
    BN_bn2binpad(bn_serial, buf, len_serial);

    char *ret = format_hex_ex(buf, len_serial, 0, 1, ":", gc);
    free(buf);
    BN_free(bn_serial);

    return ret;
}

result_t
backend_x509_write_pem(openvpn_x509_cert_t *cert, const char *filename)
{
    BIO *out = BIO_new_file(filename, "w");
    if (!out)
    {
        goto err;
    }

    if (!PEM_write_bio_X509(out, cert))
    {
        goto err;
    }
    BIO_free(out);

    return SUCCESS;
err:
    BIO_free(out);
    crypto_msg(D_TLS_DEBUG_LOW, "Error writing X509 certificate to file %s", filename);
    return FAILURE;
}

struct buffer
x509_get_sha1_fingerprint(X509 *cert, struct gc_arena *gc)
{
    const EVP_MD *sha1 = EVP_sha1();
    struct buffer hash = alloc_buf_gc((size_t)EVP_MD_size(sha1), gc);
    X509_digest(cert, EVP_sha1(), BPTR(&hash), NULL);
    ASSERT(buf_inc_len(&hash, (int)EVP_MD_size(sha1)));
    return hash;
}

struct buffer
x509_get_sha256_fingerprint(X509 *cert, struct gc_arena *gc)
{
    const EVP_MD *sha256 = EVP_sha256();
    struct buffer hash = alloc_buf_gc((size_t)EVP_MD_size(sha256), gc);
    X509_digest(cert, EVP_sha256(), BPTR(&hash), NULL);
    ASSERT(buf_inc_len(&hash, (int)EVP_MD_size(sha256)));
    return hash;
}

char *
x509_get_subject(X509 *cert, struct gc_arena *gc)
{
    BIO *subject_bio = NULL;
    BUF_MEM *subject_mem;
    char *subject = NULL;

    subject_bio = BIO_new(BIO_s_mem());
    if (subject_bio == NULL)
    {
        goto err;
    }

    X509_NAME_print_ex(subject_bio, X509_get_subject_name(cert), 0,
                       XN_FLAG_SEP_CPLUS_SPC | XN_FLAG_FN_SN | ASN1_STRFLGS_ESC_2253 | ASN1_STRFLGS_UTF8_CONVERT);

    if (BIO_eof(subject_bio))
    {
        goto err;
    }

    BIO_get_mem_ptr(subject_bio, &subject_mem);

    /* Check subject for '\0' bytes. */
    for (size_t i = 0; i < subject_mem->length; i++)
    {
        if (subject_mem->data[i] == 0)
        {
            msg(M_WARN, "ERROR: Certificate subject contains a '\\0' byte.");
            goto err;
        }
    }

    subject = gc_malloc(subject_mem->length + 1, false, gc);

    memcpy(subject, subject_mem->data, subject_mem->length);
    subject[subject_mem->length] = '\0';

err:
    BIO_free(subject_bio);
    return subject;
}


/*
 * x509-track implementation -- save X509 fields to environment,
 * using the naming convention:
 *
 *  X509_{cert_depth}_{name}={value}
 *
 * This function differs from x509_setenv below in the following ways:
 *
 * (1) Only explicitly named attributes in xt are saved, per usage
 *     of "x509-track" program options.
 * (2) Only the level 0 cert info is saved unless the XT_FULL_CHAIN
 *     flag is set in xt->flags (corresponds with prepending a '+'
 *     to the name when specified by "x509-track" program option).
 * (3) This function supports both X509 subject name fields as
 *     well as X509 V3 extensions.
 * (4) This function can return the SHA1 fingerprint of a cert, e.g.
 *       x509-track "+SHA1"
 *     will return the SHA1 fingerprint for each certificate in the
 *     peer chain.
 */

void
x509_track_add(const struct x509_track **ll_head, const char *name, msglvl_t msglevel,
               struct gc_arena *gc)
{
    struct x509_track *xt;
    ALLOC_OBJ_CLEAR_GC(xt, struct x509_track, gc);
    if (*name == '+')
    {
        xt->flags |= XT_FULL_CHAIN;
        ++name;
    }
    xt->name = name;
    xt->nid = OBJ_txt2nid(name);
    if (xt->nid != NID_undef)
    {
        xt->next = *ll_head;
        *ll_head = xt;
    }
    else
    {
        msg(msglevel, "x509_track: no such attribute '%s'", name);
    }
}

/* worker method for setenv_x509_track */
static void
do_setenv_x509(struct env_set *es, const char *name, char *value, int depth)
{
    char *name_expand;
    size_t name_expand_size;

    string_mod(value, CC_ANY, CC_CRLF, '?');
    msg(D_X509_ATTR, "X509 ATTRIBUTE name='%s' value='%s' depth=%d", name, value, depth);
    name_expand_size = 64 + strlen(name);
    name_expand = (char *)malloc(name_expand_size);
    check_malloc_return(name_expand);
    snprintf(name_expand, name_expand_size, "X509_%d_%s", depth, name);
    setenv_str(es, name_expand, value);
    free(name_expand);
}

void
x509_setenv_track(const struct x509_track *xt, struct env_set *es, const int depth, X509 *x509)
{
    struct gc_arena gc = gc_new();
#if OPENSSL_VERSION_NUMBER < 0x30000000L
    /* OpenSSL 1.1.x APIs all take non-const arguments */
    X509_NAME *x509_name = X509_get_subject_name(x509);
#else
    const X509_NAME *x509_name = X509_get_subject_name(x509);
#endif
    const char nullc = '\0';

    while (xt)
    {
        if (depth == 0 || (xt->flags & XT_FULL_CHAIN))
        {
            switch (xt->nid)
            {
                case NID_sha1:
                case NID_sha256:
                {
                    struct buffer fp_buf;
                    char *fp_str = NULL;

                    if (xt->nid == NID_sha1)
                    {
                        fp_buf = x509_get_sha1_fingerprint(x509, &gc);
                    }
                    else
                    {
                        fp_buf = x509_get_sha256_fingerprint(x509, &gc);
                    }

                    fp_str = format_hex_ex(BPTR(&fp_buf), BLEN(&fp_buf), 0, 1 | FHE_CAPS, ":", &gc);
                    do_setenv_x509(es, xt->name, fp_str, depth);
                }
                break;

                default:
                {
                    int i = X509_NAME_get_index_by_NID(x509_name, xt->nid, -1);
                    if (i >= 0)
                    {
                        const X509_NAME_ENTRY *ent = X509_NAME_get_entry(x509_name, i);
                        if (ent)
                        {
                            const ASN1_STRING *val = X509_NAME_ENTRY_get_data(ent);
                            unsigned char *buf = NULL;
                            if (ASN1_STRING_to_UTF8(&buf, val) >= 0)
                            {
                                do_setenv_x509(es, xt->name, (char *)buf, depth);
                                OPENSSL_free(buf);
                            }
                        }
                    }
                    else
                    {
                        i = X509_get_ext_by_NID(x509, xt->nid, -1);
                        if (i >= 0)
                        {
#if OPENSSL_VERSION_NUMBER < 0x40000000L
                            X509_EXTENSION *ext = X509_get_ext(x509, i);
#else
                            const X509_EXTENSION *ext = X509_get_ext(x509, i);
#endif
                            if (ext)
                            {
                                BIO *bio = BIO_new(BIO_s_mem());
                                if (bio)
                                {
                                    if (X509V3_EXT_print(bio, ext, 0, 0))
                                    {
                                        if (BIO_write(bio, &nullc, 1) == 1)
                                        {
                                            char *str;
                                            BIO_get_mem_data(bio, &str);
                                            do_setenv_x509(es, xt->name, str, depth);
                                        }
                                    }
                                    BIO_free(bio);
                                }
                            }
                        }
                    }
                }
            }
        }
        xt = xt->next;
    }
    gc_free(&gc);
}

/*
 * Save X509 fields to environment, using the naming convention:
 *
 *  X509_{cert_depth}_{name}={value}
 */
void
x509_setenv(struct env_set *es, int cert_depth, openvpn_x509_cert_t *peer_cert)
{
    const X509_NAME *x509 = X509_get_subject_name(peer_cert);

    int n = X509_NAME_entry_count(x509);
    for (int i = 0; i < n; ++i)
    {
        const X509_NAME_ENTRY *ent = X509_NAME_get_entry(x509, i);
        if (!ent)
        {
            continue;
        }
        const ASN1_OBJECT *fn = X509_NAME_ENTRY_get_object(ent);
        if (!fn)
        {
            continue;
        }
        const ASN1_STRING *val = X509_NAME_ENTRY_get_data(ent);
        if (!val)
        {
            continue;
        }
        int fn_nid = OBJ_obj2nid(fn);
        if (fn_nid == NID_undef)
        {
            continue;
        }
        const char *objbuf = OBJ_nid2sn(fn_nid);
        if (!objbuf)
        {
            continue;
        }
        unsigned char *buf = NULL;
        if (ASN1_STRING_to_UTF8(&buf, val) < 0)
        {
            continue;
        }
        size_t name_expand_size = 64 + strlen(objbuf);
        char *name_expand = malloc(name_expand_size);
        check_malloc_return(name_expand);
        snprintf(name_expand, name_expand_size, "X509_%d_%s", cert_depth, objbuf);
        string_mod(name_expand, CC_PRINT, CC_CRLF, '_');
        string_mod((char *)buf, CC_PRINT, CC_CRLF, '_');
        setenv_str_incr(es, name_expand, (char *)buf);
        free(name_expand);
        OPENSSL_free(buf);
    }
}

result_t
x509_verify_ns_cert_type(openvpn_x509_cert_t *peer_cert, const int cert_type)
{
    if (cert_type == NS_CERT_CHECK_NONE)
    {
        return SUCCESS;
    }
    if (cert_type == NS_CERT_CHECK_CLIENT)
    {
        /*
         * Unfortunately, X509_check_purpose() before OpenSSL 4.0 does some weird thing that
         * prevent it to take a const argument
         */
        result_t result =
            X509_check_purpose(peer_cert, X509_PURPOSE_SSL_CLIENT, 0) ? SUCCESS : FAILURE;
        /*
         * Note that we did not check for netscape certificate type here but
         * instead a general SSL/TLS client purpose. These nscert attributes
         * might stop being accepted by TLS libraries in the future.
         * Currently, OpenSSL 4.0 and aws-lc 1.9.0 still consider nscert client
         * as acceptable.
         *
         * So in case that this check failed, we now check if this is caused
         * by the check above no longer recognising nscert attributes.
         */
        if (result == FAILURE)
        {
            ASN1_BIT_STRING *ns;
            ns = X509_get_ext_d2i(peer_cert, NID_netscape_cert_type, NULL, NULL);
            // bit 0 is to check if certificate is the client certificate
            result = ASN1_BIT_STRING_get_bit(ns, 0) ? SUCCESS : FAILURE;
            if (result == SUCCESS)
            {
                msg(M_WARN, "X509: Certificate is a client certificate yet it's purpose "
                            "cannot be verified (check may fail in the future)");
            }
            ASN1_BIT_STRING_free(ns);
        }
        return result;
    }
    if (cert_type == NS_CERT_CHECK_SERVER)
    {
        /*
         * Unfortunately, X509_check_purpose() before OpenSSL 4.0 does some weird thing that
         * prevent it to take a const argument
         */
        result_t result =
            X509_check_purpose(peer_cert, X509_PURPOSE_SSL_SERVER, 0) ? SUCCESS : FAILURE;

        /*
         * Note that we did not check for netscape certificate type here but
         * instead a general SSL/TLS server purpose. These nscert attributes
         * might stop being accepted by TLS libraries in the future.
         * Currently, OpenSSL 4.0 and aws-lc 1.9.0 still consider nscert server
         * as acceptable.
         *
         * So in case that this check failed, we now check if this is caused
         * by the check above no longer recognising nscert attributes.
         */
        if (result == FAILURE)
        {
            ASN1_BIT_STRING *ns = X509_get_ext_d2i(peer_cert, NID_netscape_cert_type, NULL, NULL);
            // Server bit is 1 for ASN1_BIT_STRING_get_bit
            result = ASN1_BIT_STRING_get_bit(ns, 1) ? SUCCESS : FAILURE;
            if (result == SUCCESS)
            {
                msg(M_WARN, "X509: Certificate is a server certificate yet it's purpose "
                            "cannot be verified (check may fail in the future)");
            }
            ASN1_BIT_STRING_free(ns);
        }
        return result;
    }

    return FAILURE;
}

result_t
x509_verify_cert_ku(X509 *x509, const unsigned int *const expected_ku, size_t expected_len)
{
    ASN1_BIT_STRING *ku = X509_get_ext_d2i(x509, NID_key_usage, NULL, NULL);

    if (ku == NULL)
    {
        msg(D_TLS_ERRORS, "Certificate does not have key usage extension");
        return FAILURE;
    }

    if (expected_ku[0] == OPENVPN_KU_REQUIRED)
    {
        /* Extension required, value checked by TLS library */
        ASN1_BIT_STRING_free(ku);
        return SUCCESS;
    }

    unsigned int nku = 0;
    for (int i = 0; i < 8; i++)
    {
        if (ASN1_BIT_STRING_get_bit(ku, i))
        {
            nku |= 1 << (7 - i);
        }
    }

    /*
     * Fixup if no LSB bits
     */
    if ((nku & 0xff) == 0)
    {
        nku >>= 8;
    }

    msg(D_HANDSHAKE, "Validating certificate key usage");
    result_t fFound = FAILURE;
    for (size_t i = 0; fFound != SUCCESS && i < expected_len; i++)
    {
        if (expected_ku[i] != 0 && (nku & expected_ku[i]) == expected_ku[i])
        {
            fFound = SUCCESS;
        }
    }

    if (fFound != SUCCESS)
    {
        msg(D_TLS_ERRORS, "ERROR: Certificate has key usage %04x, expected one of:", nku);
        for (size_t i = 0; i < expected_len && expected_ku[i]; i++)
        {
            msg(D_TLS_ERRORS, " * %04x", expected_ku[i]);
        }
    }

    ASN1_BIT_STRING_free(ku);

    return fFound;
}

result_t
x509_verify_cert_eku(X509 *x509, const char *const expected_oid)
{
    EXTENDED_KEY_USAGE *eku = NULL;
    result_t fFound = FAILURE;

    if ((eku = (EXTENDED_KEY_USAGE *)X509_get_ext_d2i(x509, NID_ext_key_usage, NULL, NULL)) == NULL)
    {
        msg(D_HANDSHAKE, "Certificate does not have extended key usage extension");
    }
    else
    {
        msg(D_HANDSHAKE, "Validating certificate extended key usage");
        for (openssl_stack_size_t i = 0; SUCCESS != fFound && i < sk_ASN1_OBJECT_num(eku); i++)
        {
            ASN1_OBJECT *oid = sk_ASN1_OBJECT_value(eku, i);
            char szOid[1024];

            if (SUCCESS != fFound && OBJ_obj2txt(szOid, sizeof(szOid), oid, 0) != -1)
            {
                msg(D_HANDSHAKE, "++ Certificate has EKU (str) %s, expects %s", szOid,
                    expected_oid);
                if (!strcmp(expected_oid, szOid))
                {
                    fFound = SUCCESS;
                }
            }
            if (SUCCESS != fFound && OBJ_obj2txt(szOid, sizeof(szOid), oid, 1) != -1)
            {
                msg(D_HANDSHAKE, "++ Certificate has EKU (oid) %s, expects %s", szOid,
                    expected_oid);
                if (!strcmp(expected_oid, szOid))
                {
                    fFound = SUCCESS;
                }
            }
        }
    }

    if (eku != NULL)
    {
        sk_ASN1_OBJECT_pop_free(eku, ASN1_OBJECT_free);
    }

    return fFound;
}

bool
tls_verify_crl_missing(const struct tls_options *opt)
{
    if (!opt->crl_file || (opt->ssl_flags & SSLF_CRL_VERIFY_DIR))
    {
        return false;
    }

    return opt->ssl_ctx->crls == NULL || sk_X509_CRL_num(opt->ssl_ctx->crls) == 0;
}

#endif /* defined(ENABLE_CRYPTO_OPENSSL) */
