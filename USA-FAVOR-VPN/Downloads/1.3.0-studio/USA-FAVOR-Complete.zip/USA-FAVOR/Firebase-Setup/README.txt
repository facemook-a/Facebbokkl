Firebase usa-favor / schema 3
Read ../Documentation/FREE-SETUP.md and FIREBASE.md before changing the live project.
Publish the supplied canonical firestore.rules to the Standard/Native (default) database using authorized owner access. Do not deploy permissive test-mode rules.
Licensing uses licenses + bindings; the old ZIP's codes instructions are obsolete for these APKs.
Firebase Auth, the administrator admin:true claim, and actual App Check registration remain required. Public Android registration JSON files are included with the source and do not confer administrative access.
For the default Spark rules deployment use Source/USA-FAVOR-VPN/Firebase-Backend as the working directory and its firebase.json. Existing production data requires review rather than silent migration.
firebase.provider.json is the opt-in provider Functions configuration. Its paths refer to the full source Firebase-Backend directory, not this convenience copy. Do not deploy legacy Functions against schema 3.
No live deployment or real customer activation was performed by packaging this bundle.
